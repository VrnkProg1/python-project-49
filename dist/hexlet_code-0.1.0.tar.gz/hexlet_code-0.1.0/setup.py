# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

entry_points = \
{'console_scripts': ['brain-calc = brain_games.scripts.brain_calc:main',
                     'brain-even = brain_games.scripts.brain_even:main',
                     'brain-games = brain_games.scripts.brain_games:main',
                     'brain-gcd = brain_games.scripts.brain_gcd:main',
                     'brain-prime = brain_games.scripts.brain_prime:main',
                     'brain-progression = '
                     'brain_games.scripts.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': 'brain-games',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/VrnkProg1/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/VrnkProg1/python-project-49/actions)\n\n[![Maintainability](https://api.codeclimate.com/v1/badges/e1635aff1ff706e4c52a/maintainability)](https://codeclimate.com/github/VrnkProg1/python-project-49/maintainability)\n\nПроект Brain-games включает в себя 5 игр:\n    Четное-нечетное\n    Калькулятор\n    аибольший общий делитель(НОД)\n    Арифметическая прогрессия\n    Простое ли число\nВ каждой игре необходимо правильно ответить на 3 вопроса для победы. \n\nМинимальные требования:\n    1. PIP\n    2. Poetry\n    3. Пакет hexlet-code\n    4. Библиотека prompt\n\n1. Удостоверьтесь, что у вас установлен свежий pip. Потребуется версия 19 и выше. \n2. [Установите пакет и библиотеку](https://asciinema.org/a/PAcQxq5xfo6tAUYYx0LjOsj6b):\n pip install --user --force-reinstall dist/*.whl \n\n[Четное-нечетное](https://asciinema.org/a/upGne8wMNye1vUmkZximI01g4)\n\n[Калькулятор](https://asciinema.org/a/Bh8Wl2qwtPTin9de3a6TSHNrF)\n\n[Наибольший общий делитель (НОД)](https://asciinema.org/a/OJ0GJwpZMgc7rBQiBRLoEuRvL)\n\n[Арифметическая прогрессия](https://asciinema.org/a/MJ05B9jAK6HqySiofYEeIB4qk)\n\n[Простое ли число](https://asciinema.org/a/RpiVfJICH24O2H7KqedwhhTUv)',
    'author': 'nika',
    'author_email': 'khitrozhopyy_ananasik@mail.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/VrnkProg1/python-project-49.git',
    'packages': packages,
    'package_data': package_data,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
