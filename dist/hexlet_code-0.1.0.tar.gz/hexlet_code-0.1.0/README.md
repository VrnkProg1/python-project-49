### Hexlet tests and linter status:
[![Actions Status](https://github.com/VrnkProg1/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/VrnkProg1/python-project-49/actions)