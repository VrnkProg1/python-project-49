### Hexlet tests and linter status:
[![Actions Status](https://github.com/VrnkProg1/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/VrnkProg1/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/e1635aff1ff706e4c52a/maintainability)](https://codeclimate.com/github/VrnkProg1/python-project-49/maintainability)

[Asciinema even](https://asciinema.org/a/upGne8wMNye1vUmkZximI01g4)

[Ascinema calc](https://asciinema.org/a/Bh8Wl2qwtPTin9de3a6TSHNrF)
