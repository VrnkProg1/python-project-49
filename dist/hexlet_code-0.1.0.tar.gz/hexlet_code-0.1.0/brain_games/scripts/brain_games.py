#!/usr/bin/env python3

def main():
    from cli import welcome_user

if __name__ == '__main__':
    main()
