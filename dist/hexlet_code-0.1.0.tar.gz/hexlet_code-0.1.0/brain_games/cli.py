def welcome_user:
    print('Welcome to the Brain Games!')
    print('May I have your name?')
    name = input()
    name = prompt.string('May I have your name? ')
    print('Hello', name, '!')

